#coding:utf-8

class md5_str(object):
    def __init__(self,value):