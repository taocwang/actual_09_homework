#encoding: utf-8

USER_FILE = 'user.json'

MYSQL_HOST = '180.153.191.128'
MYSQL_PORT = 3306
MYSQL_USER = 'reboot'
MYSQL_PASSWD = 'reboot123'
MYSQL_DB = 'kk2'
MYSQL_CHARSET = 'utf8'
