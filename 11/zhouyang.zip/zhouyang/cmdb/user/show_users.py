#encoding:utf-8
import uconf
import login

userinfo=login.get_users(uconf.user_conf)