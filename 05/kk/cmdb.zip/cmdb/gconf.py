#encoding: utf-8

USER_FILE = 'user.json'
