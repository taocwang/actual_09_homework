#encoding:utf-8

MYSQL_HOST = '123.57.163.30'
MYSQL_PORT = 3306
MYSQL_USER = 'fqhy'
MYSQL_PASSWD = 'fqhy_com'
MYSQL_DB = 'reboot'
MYSQL_CHARSET = 'utf8'